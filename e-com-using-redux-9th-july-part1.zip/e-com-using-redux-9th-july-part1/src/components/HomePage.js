import React from 'react'
import Topbar from './Topbar'
import NavBar from './NavBar'
import Carousel from './Carousel'
import FeaturedProducts from './FeaturedProducts'

function HomePage() {
  return (
    <>
    <Topbar/>
    <NavBar/>
    <FeaturedProducts/>
    <Carousel/>
    </>
  )
}

export default HomePage